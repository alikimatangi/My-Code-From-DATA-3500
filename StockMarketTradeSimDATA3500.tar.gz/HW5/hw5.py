# define function meanReversionStrategy
def meanReversionStrategy(prices):
    print(ticker, "Mean Reversion Strategy Output:")
    
    first = True
    first_buy = 0
    i = 0 
    buy = 0 
    sell = 0
    total_profit = 0

    for price in prices:
        current_price = price
        if i > 4: # run statement when we have 5 days prior to average
            avg_price = (prices[i-1] + prices[i-2] + prices[i-3] + prices[i-4] + prices[i-5]) / 5 
            # 5 day moving average
            if current_price < (avg_price * 0.98) and buy == 0:
                buy = current_price # update the buy variable
                print("buying at: ", buy)
                
                if first: # keeping track of the price at first buy
                    first_buy = current_price # update first_buy variable
                    first = False 
                    
            elif current_price > (avg_price * 1.02) and buy != 0:
                sell = current_price # update the sell variable
                print("selling at: ", sell)
                print("trade profit: ", round((current_price - buy),2))
                
                total_profit += current_price - buy # update total_profit variable by adding the current trade profit
                total_profit = round(total_profit,2)
                buy = 0 # reset buy variable due to a sell
        
        i += 1
    
    
    print("-------------------")
    print("Total profit: ", total_profit)
    print("First buy: ", first_buy)
    final_profit_percentage = round((( total_profit / first_buy ) * 100),2)
    print("% return: ", final_profit_percentage, "\b%")
    print()
    
    returns = round((( total_profit / first_buy ) * 100),2)
    
    #return profit and returns
    return total_profit, returns


# define function simpleMovingAverageStrategy
def simpleMovingAverageStrategy(prices):
    print(ticker, "Simple Moving Average Strategy Output:")
    
    first = True
    first_buy = 0
    i = 0 
    buy = 0 
    sell = 0
    total_profit = 0

    for price in prices:
        current_price = price
        if i > 4: # run statement when we have 5 days prior to average
            avg_price = (prices[i-1] + prices[i-2] + prices[i-3] + prices[i-4] + prices[i-5]) / 5 
            # 5 day moving average
            if current_price > avg_price and buy == 0:
                buy = current_price # update the buy variable
                print("buy at: ", buy)
                
                if first: # keeping track of the price at first buy
                    first_buy = current_price # update first_buy variable
                    first = False 
                    
            elif current_price < avg_price and buy != 0:
                sell = current_price # update the sell variable
                print("sell at: ", sell)
                print("trade profit: ", round((current_price - buy),2))
                
                total_profit += current_price - buy # update total_profit variable by adding the current trade profit
                total_profit = round(total_profit,2)
                buy = 0 # reset buy variable due to a sell
        
        i += 1
    
    print("-------------------")
    print("Total profit: ", total_profit)
    print("First buy: ", first_buy)
    final_profit_percentage = round((( total_profit / first_buy ) * 100),2)
    print("% return: ", final_profit_percentage, "\b%")
    print()
    
    returns = round((( total_profit / first_buy ) * 100),2)
 
    
    return total_profit, returns


import json
# define function saveResults
def saveResults(results):
    with open("/home/ubuntu/environment/HW5/results.json", "w") as file:
        json.dump(results,file, indent=4)
        # save the results dictionary to a file called results.json

    return

# create list to store 10 company stock prices
tickers = ["AAPL", "GOOG", "ADBE", "TSLA", "DJT", "NKE", "TMO", "NVDA", "AMZN", "MSFT"]

results = {} # create dictionary called results to store prices, profits and return percentages

# loop through the list of tickers
for ticker in tickers:
    prices = [round(float(line),2) for line in open("/home/ubuntu/environment/HW5/" + ticker + ".txt").readlines()] 
    
    results[ticker+"_prices"] = prices
    
    sma_profit, sma_returns = simpleMovingAverageStrategy(prices)
    
    results[ticker + "_sma_profit"] = sma_profit
    results[ticker + "_sma_returns"] = sma_returns
    
    mr_profit, mr_returns = meanReversionStrategy(prices)
    
    results[ticker + "_mr_profit"] = mr_profit
    results[ticker + "_mr_returns"] = mr_returns

    
for key in results.keys():
    print(key, ":", results[key])


saveResults(results) #call the saveResults function


